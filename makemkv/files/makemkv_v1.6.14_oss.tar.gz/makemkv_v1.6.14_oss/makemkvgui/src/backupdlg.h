/*
    MakeMKV GUI - Graphics user interface application for MakeMKV

    Copyright (C) 2009-2010 GuinpinSoft inc <makemkvgui@makemkv.com>

    The contents of this file are subject to the Mozilla Public License
    Version 1.1 (the "License"); you may not use this file except in
    compliance with the License. You may obtain a copy of the License at
    http://www.mozilla.org/MPL/

    Software distributed under the License is distributed on an "AS IS"
    basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
    License for the specific language governing rights and limitations
    under the License.

*/
#ifndef APP_BACKUP_H
#define APP_BACKUP_H

#include <QtGui/QtGui>
#include <lgpl/aproxy.h>
#include "dirselectbox.h"

class CBackupDialog : public QDialog
{
    Q_OBJECT
public:
    CBackupDialog(CApClient* ap_client,IIconPath* iconPath,QIcon* icon,QWidget *parent = 0);
private:
    CApClient* client;
    QDialogButtonBox *buttonBox;
    QCheckBox* check_Decrypt;
public:
    int backupDecrypt;
    CDirSelectBox*  backupDir;
private slots:
    void SlotAccepted();
};


#endif // APP_BACKUP_H
