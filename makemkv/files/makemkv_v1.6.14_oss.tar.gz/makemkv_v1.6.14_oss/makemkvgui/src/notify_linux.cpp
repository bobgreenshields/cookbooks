/*
    MakeMKV GUI - Graphics user interface application for MakeMKV

    Copyright (C) 2009-2010 GuinpinSoft inc <makemkvgui@makemkv.com>

    The contents of this file are subject to the Mozilla Public License
    Version 1.1 (the "License"); you may not use this file except in
    compliance with the License. You may obtain a copy of the License at
    http://www.mozilla.org/MPL/

    Software distributed under the License is distributed on an "AS IS"
    basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
    License for the specific language governing rights and limitations
    under the License.

*/
#include "qtapp.h"
#include "notify.h"
#include <QtDBus/QDBusInterface>

static QDBusInterface*  notifyInterface = NULL;

void notifyInit()
{
    QDBusMessage msgServerInformation;

    notifyInterface = new QDBusInterface(
        QLatin1String("org.freedesktop.Notifications"),
        QLatin1String("/org/freedesktop/Notifications"),
        QLatin1String("org.freedesktop.Notifications")
        );

    if (!notifyInterface->isValid())
    {
        notifyCleanup();
        return;
    }

    msgServerInformation = notifyInterface->call(QDBus::Block,QLatin1String("GetServerInformation"));

    if (msgServerInformation.type()!=QDBusMessage::ReplyMessage)
    {
        notifyCleanup();
        return;
    }

    if (msgServerInformation.arguments().size()<3)
    {
        notifyCleanup();
        return;
    }
}

void notifyStart(QMainWindow* mainWindow,unsigned long Id,const QString &Name)
{
}

void notifyUpdate(QMainWindow* mainWindow,unsigned int Value,unsigned int MaxValue)
{
}

void notifyFinish(QMainWindow* mainWindow)
{
}

void notifyEvent(QMainWindow* mainWindow,unsigned long Id,const char* Name,const QString &Text)
{
    if (notifyInterface)
    {
        notifyInterface->call(
            QDBus::BlockWithGui,
            QLatin1String("Notify"),
            QLatin1String("makemkv"),
            QVariant((uint)0),
            QLatin1String(""),
            QLatin1String("MakeMKV"),
            Text,
            QStringList(),
            QMap<QString, QVariant>(),
            QVariant((int)3)
            );
    }
}

void notifyCleanup()
{
    delete notifyInterface;
    notifyInterface = NULL;
}

