/*
    MakeMKV GUI - Graphics user interface application for MakeMKV

    Written by GuinpinSoft inc <makemkvgui@makemkv.com>

    This file is hereby placed into public domain,
    no copyright is claimed.

*/
#ifndef VERNUM_H_INCLUDED
#define VERNUM_H_INCLUDED

#define MAKEMKV_VERSION_NUMBER  "v1.6.14"

#endif // VERNUM_H_INCLUDED

